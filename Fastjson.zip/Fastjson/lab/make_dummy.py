import zipfile, os
os.makedirs("htdocs", exist_ok=True)
with zipfile.ZipFile("htdocs/x", "w", zipfile.ZIP_STORED) as z:
    z.writestr("foo/Exception.class", b"\xca\xfe\xba\xbe dummy class bytes")
print("dummy jar written: htdocs/x")
